package patil.rahul.cineboxtma;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;
import patil.rahul.cineboxtma.bottomnavfragments.HomeFragment;
import patil.rahul.cineboxtma.bottomnavfragments.MovieFragment;
import patil.rahul.cineboxtma.bottomnavfragments.PeopleFragment;
import patil.rahul.cineboxtma.bottomnavfragments.TvShowFragment;
import patil.rahul.cineboxtma.objects.Movie;
import patil.rahul.cineboxtma.objects.People;
import patil.rahul.cineboxtma.objects.TvShows;
import patil.rahul.cineboxtma.utils.Cine;
import patil.rahul.cineboxtma.utils.CineListener;

import static patil.rahul.cineboxtma.utils.Cine.MovieEntry;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener,
        CineListener.OnPeopleClickListener, HomeFragment.OnMoreClickListener, CineListener.OnMovieClickListener, CineListener.OnTvClickListener, BottomNavigationView.OnNavigationItemReselectedListener {
    private HomeFragment mHomeFragment;
    private MovieFragment mMovieFragment;
    private PeopleFragment mPeopleFragment;
    private TvShowFragment mTvShowFragment;

    private AppBarLayout mAppBarLayout;
    private boolean doubleBackToExitPressedOnce = false;
    public static final String MEDIA_TYPE = "media_type";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView mBottomNav = findViewById(R.id.bottom_navigation);
        mAppBarLayout = findViewById(R.id.appbar);
        mAppBarLayout.setElevation(4);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle(R.string.app_name);
        mBottomNav.setOnNavigationItemSelectedListener(this);
        mBottomNav.setOnNavigationItemReselectedListener(this);

        if (savedInstanceState == null) {
            mHomeFragment = new HomeFragment();
            mMovieFragment = new MovieFragment();
            mPeopleFragment = new PeopleFragment();
            mTvShowFragment = new TvShowFragment();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.fragment, mHomeFragment).commit();
        }
    }

    protected void displayHomeFragment() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        if (mHomeFragment.isAdded()) {
            transaction.show(mHomeFragment);
        } else {
            transaction.add(R.id.fragment, mHomeFragment);
            transaction.addToBackStack(null);
        }
        if (mMovieFragment.isAdded()) {
            transaction.hide(mMovieFragment);
        }
        if (mPeopleFragment.isAdded()) {
            transaction.hide(mPeopleFragment);
        }
        if (mTvShowFragment.isAdded()) {
            transaction.hide(mTvShowFragment);
        }
        transaction.commit();
    }

    protected void displayMovieFragment() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        if (mMovieFragment.isAdded()) {
            transaction.show(mMovieFragment);
        } else {
            transaction.add(R.id.fragment, mMovieFragment);
        }
        if (mHomeFragment.isAdded()) {
            transaction.hide(mHomeFragment);
        }
        if (mPeopleFragment.isAdded()) {
            transaction.hide(mPeopleFragment);
        }
        if (mTvShowFragment.isAdded()) {
            transaction.hide(mTvShowFragment);
        }
        transaction.commit();
    }

    protected void displayPersonFragment() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        if (mPeopleFragment.isAdded()) {
            transaction.show(mPeopleFragment);
        } else {
            transaction.add(R.id.fragment, mPeopleFragment);
        }
        if (mHomeFragment.isAdded()) {
            transaction.hide(mHomeFragment);
        }
        if (mMovieFragment.isAdded()) {
            transaction.hide(mMovieFragment);
        }
        if (mTvShowFragment.isAdded()) {
            transaction.hide(mTvShowFragment);
        }
        transaction.commit();
    }

    protected void displayTvShowFragment() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        if (mTvShowFragment.isAdded()) {
            transaction.show(mTvShowFragment);
        } else {
            transaction.add(R.id.fragment, mTvShowFragment);
        }
        if (mHomeFragment.isAdded()) {
            transaction.hide(mHomeFragment);
        }
        if (mMovieFragment.isAdded()) {
            transaction.hide(mMovieFragment);
        }
        if (mPeopleFragment.isAdded()) {
            transaction.hide(mPeopleFragment);
        }
        transaction.commit();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    private void tapBackAgainToExit() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(getApplicationContext(), R.string.exit, Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }

    @Override
    public void onMovieClick(Movie movie) {
        Intent movieIntent = new Intent(this, MovieDetailActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString(MovieEntry.TITLE, movie.getTitle());
        bundle.putInt(MovieEntry.ID, movie.getId());
        movieIntent.putExtras(bundle);
        startActivity(movieIntent);
    }

    @Override
    public void onPeopleClick(People people) {
        Intent intent = new Intent(this, PeopleDetailActivity.class);
        intent.putExtra(Cine.PersonEntry.ID, people.getPeopleId());
        intent.putExtra(Cine.PersonEntry.NAME, people.getPeopleName());
        startActivity(intent);
    }

    @Override
    public void onMoreClick(String mediaType) {
        if (mediaType.equals("movie")) {
            Intent intent = new Intent(this, MovieMoreActivity.class);
            intent.putExtra(MEDIA_TYPE, mediaType);
            startActivity(intent);
        } else if (mediaType.equals("tv")) {
            Intent intent = new Intent(this, TvMoreActivity.class);
            intent.putExtra(MEDIA_TYPE, mediaType);
            startActivity(intent);
        }
    }

    @Override
    public void onTvClick(TvShows tvShows) {
        Intent intent = new Intent(this, TvDetailActivity.class);
        intent.putExtra("id", tvShows.getId());
        intent.putExtra("name", tvShows.getName());
        startActivity(intent);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        switch (itemId) {
            case R.id.nav_home:
                setTitle(R.string.app_name);
                mAppBarLayout.setElevation(8);
                mAppBarLayout.setExpanded(true);
                displayHomeFragment();
                break;
            case R.id.nav_movie:
                setTitle(R.string.nav_title_movie);
                mAppBarLayout.setElevation(0);
                mAppBarLayout.setExpanded(true);
                displayMovieFragment();
                break;
            case R.id.nav_tv:
                setTitle(R.string.nav_title_tvShow);
                mAppBarLayout.setElevation(0);
                mAppBarLayout.setExpanded(true);
                displayTvShowFragment();
                break;
            case R.id.nav_people:
                setTitle(R.string.title_people);
                mAppBarLayout.setElevation(8);
                mAppBarLayout.setExpanded(true);
                displayPersonFragment();
                break;
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemId = item.getItemId();

        if (itemId == R.id.action_search){
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }
        else if (itemId == R.id.action_settings){
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onNavigationItemReselected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        switch (itemId){
            case R.id.nav_movie:
                mMovieFragment.refreshFragment();
                break;
            case R.id.nav_tv:
                mTvShowFragment.refreshFragment();
                break;
            case R.id.nav_people:
                mPeopleFragment.refreshPeopleList();
                break;

        }
    }
}