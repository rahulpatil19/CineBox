package patil.rahul.cineboxtma.utils;

/**
 * Created by rahul on 28/2/18.
 */

public class DeveloperKey {

    public static final String DEVELOPER_KEY = "AIzaSyAj2wU8TvsLhXhNTJvwQTVkpXE2tj7A5lU";
}
