package patil.rahul.cineboxtma.utils;

import patil.rahul.cineboxtma.objects.Movie;
import patil.rahul.cineboxtma.objects.People;
import patil.rahul.cineboxtma.objects.TvShows;

public class CineListener {

    public interface OnMovieClickListener {
        void onMovieClick(Movie movie);
    }

    public interface OnTvClickListener {
        void onTvClick(TvShows tvShows);
    }

    public interface OnPeopleClickListener {
        void onPeopleClick(People people);
    }
}
